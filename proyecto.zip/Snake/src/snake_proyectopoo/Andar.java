
package snake_proyectopoo;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Andar implements Runnable{
    
    private PanelSnake panel;
    private Snake serpiente;
    private VentanaJuego ventana;
    boolean estado = true;
    
    public Andar(PanelSnake panel,Snake serpiente,VentanaJuego ventana){
        this.panel=panel;
        this.serpiente=serpiente;
        this.ventana= ventana;
    }
    @Override
    public void run() {
        while(!serpiente.getChocar()){
            this.serpiente.avanzar();
            this.panel.repaint();
            this.ventana.setTextPuntajeActual(this.serpiente.getPuntajeSerpiente());
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(Andar.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
        this.panel.MostrarJPane();
        System.exit(0);
    }
    
    public void parar(){
        this.estado=false;
    }
    
}
