
package snake_proyectopoo;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Andar implements Runnable{
    
    private PanelSnake panel;
    private Snake serpiente;
    private VentanaJuego ventana;
    
    
    public Andar(PanelSnake panel,Snake serpiente,VentanaJuego ventana){
        this.panel=panel;
        this.serpiente=serpiente;
        this.ventana= ventana;
    }
    @Override
    public void run() {
        
        while(!serpiente.getChocar()){
            if(serpiente.getCuerpo().size()%2==1&&serpiente.getComio()==true&&serpiente.getVelocidad()>50){

              serpiente.aumentarVelocidad();
              serpiente.setComio(false);
              
            }
            this.serpiente.avanzar();
            this.panel.repaint();
            this.ventana.setTextPuntajeActual(this.serpiente.getPuntajeSerpiente());
            try {
                Thread.sleep(serpiente.getVelocidad());
            } catch (InterruptedException ex) {
                Logger.getLogger(Andar.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
        this.panel.MostrarJPane();
        System.exit(0);
    }
    
}
