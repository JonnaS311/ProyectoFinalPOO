
package snake_proyectopoo;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Andar implements Runnable{
    
    private PanelSnake panel;
    private Snake serpiente;
    boolean estado = true;
    
    public Andar(PanelSnake panel,Snake serpiente){
        this.panel=panel;
        this.serpiente=serpiente;
    }
    @Override
    public void run() {
      int velocidad=serpiente.velocidad;

        while(!serpiente.getChocar()){
            if(serpiente.cuerpo.size()%2==1&&serpiente.comio==true&&velocidad>0){

              velocidad=serpiente.aumentarVelocidad();
              serpiente.comio=false;
              System.out.println(velocidad);
              
            }
            this.serpiente.avanzar();
            this.panel.repaint();
            try {
                Thread.sleep(velocidad);
            } catch (InterruptedException ex) {
                Logger.getLogger(Andar.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
        this.panel.MostrarJPane();
        System.exit(0);
    }
    
    public void parar(){
        this.estado=false;
    }
    
}
