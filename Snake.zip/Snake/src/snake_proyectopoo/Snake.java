package snake_proyectopoo;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Snake {
        
    Color color = new Color(200,150,200);
    int tammax,tam,cantidad,sobrante;
    String direccion="der";
    List<int[]> cuerpo= new ArrayList<>();
    Comida comida;
    boolean chocar;
    
    
    public Snake(int tammax, int cantidad,Comida comida){
        
        this.tammax = tammax;
        this.cantidad = cantidad;
        this.tam = tammax/cantidad;  
        this.sobrante = tammax%cantidad;
        int[] a = {cantidad/2-1,cantidad/2-1};
        int[] b = {cantidad/2,cantidad/2-1};
        this.cuerpo.add(a);
        this.cuerpo.add(b);
        this.comida = comida;
        chocar = false;
        
    }
    
    public void setDireccion(String direccion){   
        this.direccion=direccion;
    }
    
    public void setColor(Color color){
        this.color=color;
    }
    
    public Color getColor(){
        return color;
    }
    
    public List<int[]> getCuerpo(){
        return cuerpo;
    }
    
    public Comida getComida(){
        return comida;
    }
    
    public boolean getChocar(){
        return chocar;
    }

    
    public void avanzar(){
       int[] cabeza = cuerpo.get(cuerpo.size()-1);       
       int addX = 0;
       int addY = 0;
       switch(this.direccion){
            case "der": addX=1;break;
            case "izq": addX=-1;break;
            case "arr": addY=-1;break;
            case "aba": addY=1;break;           
       }

        int[] nuevo={Math.floorMod(cabeza[0]+addX,cantidad),Math.floorMod(cabeza[1]+addY,cantidad)};       
        this.Colision(nuevo);
    }
    
    public void Colision(int[] nuevo){
        for (int i = 0; i < cuerpo.size(); i++) {
            if(nuevo[0]==cuerpo.get(i)[0]&&nuevo[1]==cuerpo.get(i)[1]){
                chocar=true;
                break;
            }
        }
        if(chocar){
            
        }
    else{
            if(nuevo[0]==comida.getPosicion(0)&&nuevo[1]==comida.getPosicion(1)){
                cuerpo.add(nuevo);
                comida.generarComida(this);
            }
            else{
                cuerpo.add(nuevo);
                cuerpo.remove(0);
            }
        }
    }    
    //retornar enteros
    
    public void cambiarDireccion(String dir){
        if((this.direccion.equals("der")||this.direccion.equals("izq"))&&(dir.equals("arr")||dir.equals("aba"))){
            this.direccion = dir; 
        }
        if((this.direccion.equals("arr")||this.direccion.equals("aba"))&&(dir.equals("der")||dir.equals("izq"))){
            this.direccion = dir; 
        }
    }
    
    
}
