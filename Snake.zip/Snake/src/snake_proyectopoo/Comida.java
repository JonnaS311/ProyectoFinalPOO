package snake_proyectopoo;

import java.awt.Color;

public class Comida {
    
    private final int [] posicion = new int[2];
    private final Color color = new Color(200,200,100);
    private int cantidad;
    
    public Comida(int cantidad){
        this.cantidad = cantidad;    
    }
    
    public Color getColor(){
        return color;
    }
    
    public int getPosicion(int a){
        return posicion[a];
    }
   
    public void generarComida(Snake serpiente){
        boolean existe = false;
        int a = (int) (Math.random()*cantidad);
        int b = (int) (Math.random()*cantidad);
        for(int[] par:serpiente.getCuerpo()){
            if(a==par[0]&&b==par[1]){
                existe= true;
                this.generarComida(serpiente);
                break;
            }
        }
        if(!existe){
            this.posicion[0]=a;
            this.posicion[1]=b;
        }
    }  
}
