package snake_proyectopoo;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.text.ParseException;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;

public class Puntaje {
    private String nombre;
    private int puntaje;
    private int maxPuntaje =0;
    
    Puntaje(int puntaje){
        this.puntaje = puntaje;     
    }
    Puntaje(){
        this.nombre = "";
        this.puntaje = 0;     
    }
    public void agregar_puntaje(String nombre)throws ParseException, FileNotFoundException, IOException, org.json.simple.parser.ParseException{
         JSONObject nuevo = new JSONObject();
         JSONParser parser = new JSONParser();
         this.nombre= nombre;
         try(Reader reader = new FileReader("src\\snake_proyectopoo\\Puntajes.json")){
            nuevo = (JSONObject) parser.parse(reader);
            nuevo.put(this.nombre,this.puntaje);
            try(FileWriter file = new FileWriter("src\\snake_proyectopoo\\Puntajes.json",false
            )){
                file.write(nuevo.toJSONString());
                file.close();
            }catch(IOException e){
                System.out.print("fallo!!");
            }
        }catch(IOException e){
            System.out.print("fallo!!");
        }
    }
    
    public int puntaje_mayor() throws org.json.simple.parser.ParseException{
        JSONObject nuevo = new JSONObject();
        JSONParser parser = new JSONParser();
        try(Reader reader = new FileReader("src\\snake_proyectopoo\\Puntajes.json")){
            nuevo = (JSONObject) parser.parse(reader); 
            nuevo.values().forEach(value->{
                validarPuntaje(value.toString());
            }); 
            return this.maxPuntaje;
        }catch(IOException e){
            System.out.print("fallo!!");
        }
        return this.maxPuntaje;
    }
    public void validarPuntaje(String valor){
        int num = Integer.parseInt(valor);
        if(num>this.maxPuntaje){
            this.maxPuntaje= num;
        }
    }
    public void addPuntaje(){
        this.puntaje+=1;
    }
    
    public String get_nombre(){        
        return this.nombre;
    }
    public int get_puntaje(){        
        return this.puntaje;
    }    
    
}
