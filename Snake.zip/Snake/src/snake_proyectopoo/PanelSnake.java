package snake_proyectopoo;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author User
 */
public class PanelSnake extends JPanel {
    Color colorComida = new Color(200,200,100);
    int tammax,tam,cantidad,sobrante;
    String proxDireccion="der";
    String direccion = "der";
    
    Thread hilo;
    Andar andar;
    
    Snake serpiente;
    Comida comida;
    
    public PanelSnake(int tammax,int can,Snake serpiente){
        this.tammax= tammax;
        this.cantidad= can;
        this.tam= tammax/can;  
        this.sobrante= tammax%can;        
        this.serpiente = serpiente;
        this.comida = serpiente.getComida();
        andar= new Andar(this,serpiente);
        hilo = new Thread(andar);
        hilo.start();        
    }

    @Override
    public void paint(Graphics pintor){   
        super.paint(pintor);
        pintor.setColor(serpiente.getColor());
        for(int[] par:serpiente.getCuerpo()){
            pintor.fillRect(sobrante/2+par[0]*tam, sobrante/2+par[1]*tam, tam-2, tam-2);
        }
        pintor.setColor(comida.getColor());
        pintor.fillRect(sobrante/2+comida.getPosicion(0)*tam, sobrante/2+comida.getPosicion(1)*tam, tam-2, tam-2);
    }
    
    public void MostrarJPane(){
        JOptionPane.showMessageDialog(this, "Perdio");
    }
}
